<?php if($errors_top && $errors->any()): ?>

<div class="container">
  <div class="row">
    <div class="col-6 m-auto">

      <div class="alert alert-danger text-center">
        <h6>Hey, you have some errors:</h6>


        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>