 
<?php $__env->startSection('main_content'); ?>

<!-- Intro Section -->
<section class="inner-intro bg-image overlay-light parallax parallax-background1" data-background-img="<?php echo e(asset('images/about.jpg')); ?>">
  <div class="container">
    <div class="row title">
      <h2 class="h2">Paymeny and Shipping</h2>

    </div>
  </div>
</section>
<!-- End Intro Section -->








<div class="container-fluid mb-5">
  <div class="row">
    <div class="col-md-6">
      <h2>Payment and Shipping</h2>
      <div class="col-md-6">
        <div class="Pricing-box highlight">
          <div class="price-title spacing-box">
            <h4>Your items</h4>
          </div>
          <hr />

          <div class="spacing-box">

          </div>
          <hr /> <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="pricing-features spacing-grid">
            <h3><?php echo e($item['price']); ?> $ <strong>x</strong> <?php echo e($item['quantity']); ?></h3>

            <div class="price-tenure"><?php echo e($item['name']); ?> $</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
          <h4>TOTAL + FREE Shipping</h4>

          <h4><?php echo e($paymentTotal); ?> $</h4>

          <hr />
          <div class="spacing-grid">
            <a class="btn btn-md">Back to cart</a>
            <a href="<?php echo e(url( 'shop/order')); ?>" class="btn btn-md">pay</a>

          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>