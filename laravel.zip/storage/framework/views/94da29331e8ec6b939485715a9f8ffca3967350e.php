<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>
        <?php if( !empty($pageTitle) ): ?> <?php echo e($pageTitle); ?> <?php endif; ?>
    </title>
    <link rel='shortcut icon' type='image/x-icon' href="<?php echo e(asset('favicon.ico')); ?>" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="yinonsade">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <?php echo $__env->make('inc.css_header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script>
        var BASE_URL = "<?php echo e(url('')); ?>/";
    </script>

    <!-- Main costum Style css -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" />

</head>

<body>
    <!-- Preloader -->
    
    <!--  End Preloader -->
    <!-- Site Wraper -->
    <div class="wrapper">
        <!-- Header ("header--dark", "header-transparent", "header--sticky")-->
        <header id="header" class="header header-transparent header--sticky">
            <!-- Nav Bar -->
    <?php echo $__env->make('inc.topmenu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </header>
        <!-- End Header -->
        <?php echo $__env->yieldContent('main_content'); ?>
    <?php echo $__env->make('inc.error_messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- FOOTER -->
        <footer class="fixed-bottom bg-dark text-center mt-5">
            <p class="">
                created by <b>YINON-SADE</b> <?php echo e(date('Y')); ?> © <a> | E2.1.8</a>
            </p>
        </footer>
        <!-- END FOOTER -->
    </div>
    <!-- Site Wraper End -->
    <!-- JS -->
    <?php echo $__env->make('inc.js_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>