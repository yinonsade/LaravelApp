 
<?php $__env->startSection('main_cms_content'); ?>

<?php  $counterA = 1 ?>
<div class="row">
  <div class="col-12 mt-5">
    <h1 class="h2">View site orders</h1>
    <hr>
  </div>
</div>
<div class="row">
  <div class="col-12">
    <table class="table table-bordered table-dark table-responsive-md text-center mt-5 mb-5">
      <thead>
        <tr>
          <th>Number</th>
          <th class="mr-5">User </th>
          <th>Total</th>
          <th>Details</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr></tr>
        <td><?php echo e($counterA); ?></td>
        <td>name: <?php echo e($item->name); ?><br><br>
          <p><strong>email: </strong><?php echo e($item->email); ?></p>
          <p><strong>address: </strong></p>
          <p>name : <?php echo e($item->aname); ?> |<br> line 1: <?php echo e($item->aline1); ?> |<br> line 2: <?php echo e($item->aline2); ?>|<br> city: <?php echo e($item->acity); ?>

            | regioun: <?php echo e($item->aregion); ?> |<br> zip code: <?php echo e($item->apostalcode); ?> | country: <?php echo e($item->acountry); ?></p>
          <p><strong> phone: </strong><?php echo e($item->phone); ?></p>
        </td>
        <td><?php echo e($item->total); ?></td>
        <td>
          <ul>
            <?php $__currentLoopData = unserialize($item->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <img class="w-25 p-3" src="<?php echo e(asset( 'images/' . $order['attributes']['image'])); ?>" alt="">
            <li><?php echo e($order['name']); ?></li>
            <li>Size:<?php echo e($order['attributes']['size']); ?></li>
            <li>Color:<?php echo e($order['attributes']['color']); ?></li>
            <li>Price item: $<?php echo e($order['price']); ?></li>
            <li> Quantity: <?php echo e($order['quantity']); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </td>
        <td> <?php echo e(date('d/m/Y'), strtotime($item->created_at)); ?></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>