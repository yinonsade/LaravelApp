 
<?php $__env->startSection('main_cms_content'); ?>

<div class="row">
  <div class="col-12 mt-5">
    <h1 class="h2">Add Product Form</h1>
    <a href="<?php echo e(url('cms/products/')); ?>"> <button class="mt-3 mb-3 btn btn-primary btn-lg btn3d"> <i class="fas fa-arrow-circle-left"></i></button></a>
    <hr>
  </div>
</div>
<div class="row">
  <div class="col-md-8">
    <form action="<?php echo e(url('cms/products')); ?>" enctype="multipart/form-data" method="POST" autocomplete="off" novalidate="novalidate">
      <?php echo csrf_field(); ?>
      <div class="form-group mt-2">
        <label for="categories-id"><span class="text-danger">*</span> Category </label>
        <select class="form-control" name="categorie_id" id="categorie-id">
            <option value="">Choose Category...</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option <?php if( old('categories_id') == $item['id'] ): ?> selected="selected"      
          <?php endif; ?> value="<?php echo e($item['id']); ?>"> <?php echo e($item['ctitle']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
      </div>
      <div class="form-group">
        <label for="title"> <span class="text-danger">*</span> Title</label>
        <input value="<?php echo e(old('title')); ?>" class="form-control origin-text" type="text" name="title" id="title">
      </div>

      <div class="form-group">
        <label for="url"> <span class="text-danger">*</span> Url</label>
        <input value="<?php echo e(old('url')); ?>" class="form-control target-text" type="text" name="url" id="url">
      </div>
      <div class="form-group">
        <label for="price"> <span class="text-danger">*</span> Price</label>
        <input value="<?php echo e(old('url')); ?>" class="form-control" type="text" name="price" id="price">
      </div>
      <div class="form-group">
        <label for="article"><span class="text-danger">*</span>Article</label>
        <textarea name="article" id="article" class="form-control"><?php echo e(old('article')); ?></textarea>
      </div>
      <label for="image">Product Image</label>
      <div class="input-group mb-3">
        <div class="input-group-prepend">
          <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
        </div>
        <div class="custom-file">
          <input name="image" type="file" class="custom-file-input" id="image" aria-describedby="inputGroupFileAddon01">
          <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
        </div>
      </div>

      <input type="submit" class="btn btn-success btn-lg btn3d btn-block" type="submit" value="Save">
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>