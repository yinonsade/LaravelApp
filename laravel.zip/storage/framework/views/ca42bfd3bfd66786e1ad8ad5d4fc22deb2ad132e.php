 
<?php $__env->startSection('main_content'); ?> 

<!-- Intro Section -->
<section class="inner-intro bg-image overlay-light parallax parallax-background1" data-background-img="<?php echo e(asset('images/about.jpg')); ?>">
    <div class="container">
        <div class="row title">
            <h2 class="h2">Sign up</h2>

        </div>
    </div>
</section>
<!-- End Intro Section -->

<!--Login Section -->
<section id="login-register" class="mt-5 mb-2">
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3 col-sm-8 offset-sm-2">
                <div class="border-box">
                    <h4>Sign up to a have a new account</h4>
                    <form action="" method="POST" novalidate="novalidate" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <div class="form-field-wrapper">
                            <label for="email">Name</label>
                            <input value="<?php echo e(old('name')); ?>" type="text" placeholder="Enter your name" name="name" id="name" class="input-sm form-full">
                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        </div>
                        <div class="form-field-wrapper">
                            <label for="email">Email address</label>
                            <input value="<?php echo e(old('email')); ?>" type="email" placeholder="Enter your Email" name="email" id="email" class="input-sm form-full">
                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>

                        </div>
                        <div class="form-field-wrapper">
                            <label for="password">Choose Password</label>
                            <input type="password" placeholder="Enter Password" name="password" id="password" class="input-sm form-full">
                            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                        </div>

                        <div class="form-field-wrapper">
                            <label for="telephone">Phone number</label>
                            <input type="tel" placeholder="Enter your Phone number" name="telephone" id="telephone" class="input-sm form-full">
                            <span class="text-danger"><?php echo e($errors->first('telephone')); ?></span>
                        </div>


                        <div class="form-field-wrapper">
                            <label for="email">Address</label>
                            <input value="<?php echo e(old('address')); ?>" type="text" placeholder="Enter your address" name="address" id="address" class="input-sm form-full">
                            <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                        </div>


                        <button name="submit" type="submit" class="btn btn-md btn-black">Signup Now</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- End Login Section -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>