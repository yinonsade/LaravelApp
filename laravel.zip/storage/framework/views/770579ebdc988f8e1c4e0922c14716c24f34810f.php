 
<?php $__env->startSection('main_content'); ?>


<!-- Shop Item -->
<section class="inner-intro bg-image overlay-dark parallax parallax-background1" data-background-img="<?php echo e(asset('images/model-4.jpg')); ?>">
    <div class="container">
        <div class="row title">
            <h2 class="h2">Shop By categories</h2>

        </div>
    </div>
</section>
<!-- End Intro Section -->
<div class="container">
    <!-- Sort List -->
    <div class="row mt-5 mb-5 text-center">
        <div class="col-md-12 shop-filter">

            <a href=<?php echo e(url( 'shop')); ?>>
                          <a href=<?php echo e(url( 'shop/all-products')); ?>>
                              <button class="btn btn-sm btn-black-line">All products</button></a>
        </div>
    </div>
</div>
<hr>
<div class="container">
    <div class="row">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-5 mt-3">
            <div class="item-box">
                <!-- Shop item images -->
                <div class="shop-item">
                    <div class="item-img">
                        <img src="<?php echo e(asset('images/' . $category['cimage'])); ?>" alt="<?php echo e($category['ctitle']); ?> category image" />
                    </div>
                    <div class="item-mask">
                        <div class="item-mask-detail">
                            <div class="item-mask-detail-ele">
                                <a class="btn btn-line-xs btn-white-line" href="<?php echo e(url('shop/' . $category['curl'])); ?>">View Products</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Shop item images -->

                <!-- Shop item info -->
                <div class="shop-item-info">
                    <h4 class="shop-item-name"><?php echo e($category['ctitle']); ?></h4>
                    <h6 class="shop-item-name"><?php echo $category['carticale']; ?></h6>
                </div>
                <!-- Shop item info -->

            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>