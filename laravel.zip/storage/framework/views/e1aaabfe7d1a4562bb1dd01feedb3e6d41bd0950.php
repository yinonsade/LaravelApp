 
<?php $__env->startSection('main_content'); ?>

<!-- Intro Section -->
<section class="inner-intro bg-image overlay-light parallax parallax-background1" data-background-img="<?php echo e(asset('images/about.jpg')); ?>">
    <div class="container">
        <div class="row title">
            <h2 class="h2">Contact us</h2>

        </div>
    </div>
</section>
<!-- End Intro Section -->

<!-- Contact Section -->



<div class="container-fluid">
    <div class="row">
        <div class="col-12">

            Hello <i><?php echo e($demo->receiver); ?></i>,
            <p>This is a demo email for testing purposes! Also, it's the HTML version.</p>

            <p><u>Demo object values:</u></p>

            <div>
                <p><b>Demo One:</b>&nbsp;<?php echo e($demo->demo_one); ?></p>
                <p><b>Demo Two:</b>&nbsp;<?php echo e($demo->demo_two); ?></p>
            </div>

            <p><u>Values passed by With method:</u></p>

            <div>
                <p><b>testVarOne:</b>&nbsp;<?php echo e($testVarOne); ?></p>
                <p><b>testVarTwo:</b>&nbsp;<?php echo e($testVarTwo); ?></p>
            </div>

            Thank You,
            <br/>
            <i><?php echo e($demo->sender); ?></i>



        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <section class="ptb ptb-sm-80">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 offset-md-3 text-center">
                            <h3>Keep In Touch</h3>
                            <p class="lead">Nullam dictum felis eu pede mollis pretium leo eget bibendum sodales augue velit cursus. tellus
                                eget condimentum rhoncus sem quam semper libero.</p>
                        </div>
                    </div>
                    <div class="spacer-75"></div>
                    <div class="row">
                        <div class="col-md-6 offset-md-3">
                            <!-- Contact FORM -->
                            <form class="contact-form" id="contact" role="form">

                                <!-- IF MAIL SENT SUCCESSFULLY -->
                                <h6 class="successContent">
                                    <i class="fa fa-check left" style="color: #5cb45d;"></i>Your message has been sent successfully.
                                </h6>
                                <!-- END IF MAIL SENT SUCCESSFULLY -->

                                <!-- MAIL SENDING UNSUCCESSFULL -->
                                <h6 class="errorContent">
                                    <i class="fa fa-exclamation-circle left" style="color: #e1534f;"></i>There was a problem
                                    validating the form please check!
                                </h6>
                                <!-- END MAIL SENDING UNSUCCESSFULL -->

                                <div class="form-field-wrapper">
                                    <input class="input-sm form-full" id="form-name" type="text" name="form-name" placeholder="Your Name" required>
                                </div>

                                <div class="form-field-wrapper">
                                    <input class="input-sm form-full" id="form-email" type="email" name="form-email" placeholder="Email" required>
                                </div>

                                <div class="form-field-wrapper">
                                    <input class="input-sm form-full" id="form-subject" type="text" name="form-subject" placeholder="Subject">
                                </div>

                                <div class="form-field-wrapper">
                                    <textarea class="form-full" id="form-message" rows="7" name="form-message" placeholder="Your Message" required></textarea>
                                </div>

                                <button class="btn btn-md btn-black form-full" type="submit" id="form-submit" name="submit">Send Message</button>
                            </form>
                            <!-- END Contact FORM -->
                        </div>
                    </div>
                </div>
            </section>
            <!-- Contact Section -->

        </div>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>