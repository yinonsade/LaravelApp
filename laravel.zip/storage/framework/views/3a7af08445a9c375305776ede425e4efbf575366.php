 
<?php $__env->startSection('main_cms_content'); ?>
<div class="row">
  <div class="col-12 mt-5">
    <h1 class="h2">Edit site Menu</h1>
    <a href="<?php echo e(url('cms/menu/create')); ?>"><button class="mt-3 mb-3 btn btn-primary btn-lg btn3d"> <i class="fas fa-plus-circle">Add Menu Link</i></button></a>
    <hr>
  </div>
</div>
<div class="row">
  <div class="col-12">
    <table class="table table-bordered table-dark table-responsive-md text-center mt-5 mb-5">
      <thead>
        <tr>
          <th class="mr-5">Link</th>
          <th>Last Update</th>

          <th>Operation</th>

        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr></tr>
        <td><?php echo e($item['link']); ?></td>
        <td> <?php echo e(date('d/m/Y'), strtotime($item['updated_at'])); ?></td>
        <td>
          <a class="mr-2 ml-3 text-white" href="<?php echo e(url('cms/menu/' . $item['id'] . '/edit')); ?>"><i class="fas fa-pencil-alt"></i> Edit</a>          |
          <a class="ml-2 text-white" href="<?php echo e(url('cms/menu/' . $item['id'])); ?>"><i class="fas fa-trash-alt "></i> Delete</a>
        </td> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>