<!-- Preloader -->
<section id="preloader">
  <div class="loader" id="loader">
    <div class="loader-img"></div>
  </div>
</section>
<!-- End Preload er -->
<nav id="navigation" class="header-nav">
  <div class="container">
    <div class="logo-headr row d-flex flex-md-row align-items-center">
      <div class="logo  mr-auto">
        <!--logo-->
        <a onclick="openNav()" id="showHide">
              <img class="logo-dark" src="<?php echo e(asset('images/e22_logo_w.jpg')); ?>" alt="logo" />
              <img class="logo-light" src="<?php echo e(asset('images/e22_logo_b.jpg')); ?>" alt="logo" />
            </a>
      </div>
      <!--sidenav-->

      <div id="sideNavigation" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()" id="hideShow">&times;</a>
        <p class="nav-menu-item">
          <a href="<?php echo e(url('')); ?>">Home</a>
        </p>
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url($item['url'])); ?>">
          <li class="nav-menu-item">
            <?php echo e($item['link']); ?>

          </li>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <p class="nav-menu-item mt-5">
          <a href="<?php echo e(url('/shop')); ?>">Shop</a>
        </p>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href=<?php echo e(url( 'shop/' . $category[ 'curl'])); ?>>
          <li><?php echo e($category['ctitle']); ?></li>
        </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a href=<?php echo e(url( 'shop/all-products' )); ?>>
          <li>All products</li>
        </a>
        <div class="mt-5">
          <?php if(! Session::has('user_id')): ?>
          <p class=" log-custom"><a href="<?php echo e(url('user/signin' )); ?>">Signin</a></p>
          <p class=" log-custom"><a href="<?php echo e(url('user/signup')); ?>">Signup</a></p>
          <?php else: ?>
          <p class=" log-custom"><a href="<?php echo e(url('user/logout' )); ?>">Log out</a></p>
          <p class=" log-custom"><a href="<?php echo e(url('user/profile')); ?>"><?php echo e(Session::get('user_name')); ?></a></p>
          <?php endif; ?>
        </div>
      </div>


      <div class="nav-menu ml-auto">
        <ul class="">
          <li class="nav-menu-item">
            <a href="<?php echo e(url('')); ?>">Home</a>
          </li>

          <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="nav-menu-item">
            <a href="<?php echo e(url($item['url'])); ?>"><?php echo e($item['link']); ?></a>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <li class="nav-menu-item">
            <a href="#">Shop</a>
            <div class="nav-dropdown col2-dropdown left">
              <div class="row text-center">
                <div class="col-lg-6">
                  <ul>
                    <li><a href="<?php echo e(url('shop' )); ?>">Shop by categories</a></li>

                  </ul>
                </div>
                <div class="col-lg-6">
                  <ul>
                    <li><a href="<?php echo e(url('shop/all-products')); ?>">See all</a></li>

                  </ul>
                </div>


                <li class="nav-menu-item">
                  <?php if(! Session::has('user_id')): ?>
                  <a href="#">Register</a>
                  <div class="nav-dropdown col2-dropdown left">
                    <div class="row text-center">
                      <div class="col-lg-6">
                        <ul>
                          <li><a href="<?php echo e(url('user/signin' )); ?>">Signin</a></li>

                        </ul>
                      </div>
                      <div class="col-lg-6">
                        <ul>
                          <li><a href="<?php echo e(url('user/signup')); ?>">Signup</a></li>

                        </ul>
                      </div>

                    </div>
                  </div>
                  <?php else: ?>
                  <a href="#">Your Account</a>
                  <div class="nav-dropdown col2-dropdown left">
                    <div class="row text-center">
                      <div class="col-lg-6">
                        <ul>
                          <li><a href="<?php echo e(url('user/logout' )); ?>">Log out</a></li>
                        </ul>
                      </div>

                      <?php if( Session::has('is_admin')): ?>
                      <div class="col-lg-6">
                        <ul>
                          <li><a href="<?php echo e(url('cms/dashboard')); ?>">Admin Panel</a></li>

                        </ul>
                      </div>
                      <?php endif; ?>

                      <div class="col-lg-6">
                        <ul>
                          <li><a href="<?php echo e(url('user/profile')); ?>"><?php echo e(Session::get('user_name')); ?></a></li>

                        </ul>
                      </div>

                    </div>
                  </div>
                  <?php endif; ?>
                </li>
        </ul>
        </div>
        <div class="nav-icons">
          <div class="nav-icon-item d-lg-none">
            <span class="nav-icon-trigger menu-mobile-btn align-middle"><i class="ion"></i></span>
          </div>
          <a href="<?php echo e(url('shop/checkout')); ?>">
            <div class="nav-icon-item total-cart">
              <span class="nav-icon-trigger sidebar-menu_btn align-middle"> 
                <i class="fas fa-shopping-cart"><span class="text-danger">
                    <?php if( ! Cart::isEmpty() ): ?>
                    + <?php echo e(Cart::getTotalQuantity()); ?>

                    <?php endif; ?>
                    <span></i></span>
            </div>
          </a>

        </div>
        </div>
      </div>
</nav>