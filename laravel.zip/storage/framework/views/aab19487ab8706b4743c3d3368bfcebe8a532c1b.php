 
<?php $__env->startSection('main_cms_content'); ?>
<div class="row">
  <div class="col-12 mt-5">
    <h1 class="h2">View site orders</h1>
    <hr>
  </div>
</div>
<div class="row">
  <div class="col-12">
    <table class="table-bordered text-center mt-5 mb-5">
      <thead>
        <tr>
          <th class="mr-5">User </th>
          <th>Total</th>
          <th>Details</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr></tr>
        <td>name: <?php echo e($item->name); ?><br><br>
          <p><strong>email: </strong><?php echo e($item->email); ?></p>
          <p><strong>address: </strong><?php echo e($item->address); ?></p>
          <p><strong> phone: </strong><?php echo e($item->phone); ?></p>
        </td>
        <td><?php echo e($item->total); ?></td>
        <td>
          <ul>
            <?php $__currentLoopData = unserialize($item->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($order['name']); ?>, price item: $<?php echo e($order['price']); ?>, Quantity: <?php echo e($order['quantity']); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </td>
        <td> <?php echo e(date('d/m/Y'), strtotime($item->created_at)); ?></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>