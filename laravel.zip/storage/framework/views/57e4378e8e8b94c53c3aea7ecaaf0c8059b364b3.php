<h3>you have a new contact via the contact form</h3>

<div>
  <?php echo e($bodyMessage); ?>

</div>
<p>
  from: <?php echo e($name); ?>

</p>
<p>
  send via <?php echo e($email); ?>

</p>