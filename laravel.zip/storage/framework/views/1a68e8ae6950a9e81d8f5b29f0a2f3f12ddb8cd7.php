 
<?php $__env->startSection('main_cms_content'); ?>

<div class="row">
  <div class="col-12 mt-5">
    <h3 class="h3">Are You sure that you want to delete this item?</h3>
    <hr>
  </div>
</div>
<div class="row">
  <div class="col-md-8 text-center">
    <form action="<?php echo e(url('cms/content/' . $item_id)); ?>" method="POST" autocomplete="off" novalidate="novalidate">
      <?php echo csrf_field(); ?> <?php echo e(method_field('DELETE')); ?>

      <input class="mt-3 mb-3 btn btn-danger btn-lg btn3d" name="submit" type="submit" value="Delete">
      <a class="mt-3 mb-3 btn btn-success btn-lg btn3d" href="<?php echo e(url('cms/content')); ?>"> Cancel</a>

    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>