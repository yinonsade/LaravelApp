<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>
        <?php if( !empty($pageTitle) ): ?> <?php echo e($pageTitle); ?> <?php endif; ?>
    </title>
    <link rel='shortcut icon' type='image/x-icon' href="<?php echo e(asset('favicon.ico')); ?>" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="yinonsade">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <?php echo $__env->make('inc.css_header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script>
        var BASE_URL = "<?php echo e(url('')); ?>/";
    </script>

    <!-- Main costum Style css -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css" />

    <style>
        body {
            padding-right: 0px !important;
            overflow-y: hidden !important;
        }

        .fx:hover {
            background-color: black;
            color: white;
            opacity: 0.5;
        }

        img {

            max-width: 300px;
            margin-top: 15%;
        }
    </style>

</head>

<body>




    <div class="container-fluid">

        <div class="row">
            <div class="col-12">
                <img class="rounded mx-auto d-block" src="<?php echo e(asset('images/smallogo.jpg')); ?>" alt="">
            </div>
            <div class="col-12 mt-5">
                <a href="<?php echo e(url('home')); ?>">
                    <h1 class="text-center font-weight-bold mt-5"><u class="fx">ENTER</u></h1>
                </a>
            </div>
        </div>


    </div>
    <?php echo $__env->make('inc.js_footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>