<link href="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>

<style>
  .invoice-title h2,
  .invoice-title h3 {
    display: inline-block;
  }

  .table>tbody>tr>.no-line {
    border-top: none;
  }

  .table>thead>tr>.no-line {
    border-bottom: none;
  }

  .table>tbody>tr>.thick-line {
    border-top: 2px solid;
  }
</style>

<!------ Include the above in your HEAD tag ---------->
<?php $date = date('Y/m/d H:i:s'); 
?>
<div class="container">
  <div class="row">
    <div class="col-xs-12">
      <div class="invoice-title">
        <h2>E218</h2><br>
        <h2>Invoice| <?php echo e($date); ?> </h2>
      </div>
      <hr>
      <div class="row">
        <div class="col-xs-6">
          <address>
    				<strong>Billed To:</strong><br>
          <?php echo e($bodyMessage->aname); ?><br>
          <?php echo e($bodyMessage->aline1); ?><br>
          <?php echo e($bodyMessage->aline2); ?><br>
    <?php echo e($bodyMessage->acity); ?>, <?php echo e($bodyMessage->aregion); ?>,<br>
     <?php echo e($bodyMessage->apostalcode); ?> , <?php echo e($bodyMessage->acountry); ?>

    				</address>
        </div>
        <div class="col-xs-6 text-right">
          <address>
                <strong>Shipped To:</strong><br>
              <?php echo e($bodyMessage->aname); ?><br>
              <?php echo e($bodyMessage->aline1); ?><br>
              <?php echo e($bodyMessage->aline2); ?><br>
        <?php echo e($bodyMessage->acity); ?>, <?php echo e($bodyMessage->aregion); ?>,<br>
         <?php echo e($bodyMessage->apostalcode); ?> , <?php echo e($bodyMessage->acountry); ?>

                </address>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-6">
          <address>
    					<strong>Payment Method:</strong><br>
Paypal...
<?php echo e($bodyMessage->email); ?>    				</address>
        </div>
        <div class="col-xs-6 text-right">
          <address>
    					<strong>Order Date:</strong><br>
          <?php echo e($bodyMessage->created_at); ?><br><br>
    				</address>
        </div>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title"><strong>Order summary</strong></h3>
        </div>
        <div class="panel-body">
          <!-- foreach ($order->lineItems as $line) or some such thing here -->
          <?php $__currentLoopData = unserialize($bodyMessage->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <h3>Item:</h3>
          <hr>
          <li><?php echo e($item['name']); ?></li>
          <li>Size:<?php echo e($item['attributes']['size']); ?></li>
          <li>Color:<?php echo e($item['attributes']['color']); ?></li>
          <li>Price item: $<?php echo e($item['price']); ?></li>
          <li> Quantity: <?php echo e($item['quantity']); ?></li>
          <hr> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <h3>Total payout</h3>
          <p><?php echo e($bodyMessage->total); ?> $</p>



        </div>
      </div>
    </div>
  </div>
</div>

<div container text-center>
  <hr>
  <p>Thank you for shooping with us (c)E2.1.8 www.e218.com</p>
  <hr>
</div>