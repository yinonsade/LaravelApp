 
<?php $__env->startSection('main_content'); ?>



<!-- Intro Section -->
<section class="inner-intro bg-image overlay-light parallax parallax-background1" data-background-img="<?php echo e(asset('images/about.jpg')); ?>">
  <div class="container">
    <div class="row title m-auto">
      <h2 class="h2">Payment and Shipping</h2>
    </div>
  </div>
</section>
<!-- End Intro Section -->
<div class="container-fluid mb-5">
  <div class="row text-center">
    <div class="col-md-4 Pricing-box highlight mt-3 ">
      <h2>Payment and terms</h2>
      <a class="btn btn-md btn-black mt-5" href="<?php echo e(url('terms')); ?>" target="_blank">
        <p class="text-white">Read Terms and Condtions</p>
      </a><br>

      <button class="btn btn-md btn-black mt-5 mb-4" id="agree" onclick="agree()"><p class="text-white">i agree to terms and conditions</p> </button>


      <hr>
      <div class=" text-center mt-5">
        <div id="paypal-button"></div>
        <script src="https://www.paypalobjects.com/api/checkout.js"></script>
        <script>
          function agree(){
            paypal.Button.render({
            // Configure environment
            env: 'sandbox',
            client: {
              sandbox: 'Ae0SYamNvjwPhN4joUpdWSYpkySav5WAliw8hj883VZmPC4VgqbxBF_O1bRHyV-m2n3oBiHLXeJdnKj2',
              production: 'demo_production_client_id'
            },
            // Customize button (optional)
            locale: 'en_US',
            style: {
              size: 'large',
              color: 'gold',
              shape: 'pill',
            },
        
            // Enable Pay Now checkout flow (optional)
            commit: true,
        
            // Set up a payment
            payment: function(data, actions) {
              return actions.payment.create({
                transactions: [{
                  amount: {
                    total: '<?php echo e($paymentTotal); ?>',
                    currency: 'USD'
                  }
                }]
              });
            },
            // Execute the payment
            onAuthorize: function(data, actions) {
              return actions.payment.execute().then(function() {
                // Show a confirmation message to the buyer
                window.alert('Thank you for your purchase!');
                window.location.replace("<?php echo e(url( 'shop/order')); ?>");
              });
            }
          }, '#paypal-button');
        };
        </script>
      </div>

    </div>
    <div class="col-md-8 mt-3">

      <div class="Pricing-box highlight">
        <h2>Total & Shiping</h2>

        <?php $__currentLoopData = $getProfile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="spacing-box">

          <h3>Hey, <?php echo e($info->name); ?></h3>
          <h4>Your shiping address is:</h4>
          <h5><?php echo e($info->aname); ?>,<?php echo e($info->aline1); ?>,<?php echo e($info->aline2); ?>,<?php echo e($info->acity); ?>,<br><?php echo e($info->aregion); ?>,<?php echo e($info->apostalcode); ?>,<?php echo e($info->acountry); ?></h5>
          <a class="btn btn-md btn-black" href="<?php echo e(url('user/profile?rn=shop/payment')); ?>">
            <p class="text-white">Change your details</p>
          </a>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <div class="price-title">
          <h4>Your items</h4>
        </div>
        <hr /> <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="pricing-features spacing-grid">
          <h3><?php echo e($item['price']); ?> $ <strong>x</strong> <?php echo e($item['quantity']); ?></h3>

          <div class="price-tenure text-dark"><?php echo e($item['name']); ?></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <h4>TOTAL + FREE Shipping</h4>

        <h4><?php echo e($paymentTotal); ?> $</h4>

        <hr />
        <div class="spacing-grid">
          <a href="<?php echo e(url('shop/checkout')); ?>" class="btn btn-md">Back to cart</a>

        </div>
      </div>

    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>