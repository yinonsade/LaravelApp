 
<?php $__env->startSection('main_content'); ?> <?php 
?>




<!-- CONTENT --------------------------------------------------------------------------------->
<!-- Intro Section -->
<section class="inner-intro bg-image overlay-dark parallax parallax-background1" data-background-img="<?php echo e(asset('images/model-3.jpg')); ?>">
  <div class="container">
    <div class="row title">
      <h2 class="h2"><?php echo e($product['ptitle']); ?></h2>

    </div>
  </div>
</section>
<!-- End Intro Section -->

<div class="container">
  <!-- Sort List -->
  <div class="row mt-5 mb-5 text-center">
    <div class="col-md-6 shop-filter">
      <p class="mb-2"><strong>Go to:</strong> </p>
      <a href=<?php echo e(url( 'shop/all-products')); ?>>
                <button class="btn btn-md btn-black-line">All products</button>
              </a>
      <a href=<?php echo e(url( 'shop')); ?>>
                <button class="btn btn-md btn-black-line">Categories page</button>
              </a>
    </div>

    <div class="col-md-6 shop-filter">
      <p class="mb-2"><strong>Shop by Category:</strong> </p>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href=<?php echo e(url( 'shop/' . $category[ 'curl'])); ?>>
          <button class="btn btn-md btn-black-line"><?php echo e($category['ctitle']); ?></button>
        </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<hr>

<!-- Shop Item Detail Section -->
<section id="shop-item" class="ptb ptb-sm-80">
  <div class="container">
    <div class="row ">
      <!-- Shop Item -->
      <div class="col-md-6 mb-sm-60">
        <div class="owl-carousel image-slider o-flow-hidden">

          <div class="item">
            <img src="<?php echo e(asset('images/' . $product['pimage'])); ?>" alt="" />
          </div>
          <div class="item">
            <img src="<?php echo e(asset('images/' . $product['pimage2'])); ?>" alt="" />
          </div>


        </div>

      </div>
      <!-- End Shop Item -->

      <!-- Shop info -->
      <div class="col-md-6 text-center">
        <div class="shop-detail-info">
          <h4><?php echo e($product['ptitle']); ?></h4>
          <div class="shop-item-price mtb-15 ptb-15"><span>$<?php echo e($product['price']); ?></span></div>
          <hr />
          <p class="ptb-15"><?php echo $product['particle']; ?></p>

          <?php if(! Cart::get($product['id'])): ?>
          <a data-id="<?php echo e($product['id']); ?>" class="btn btn-lg btn-black form-full add-to-cart-btn  text-white"><i class="fa fa-shopping-bag left"></i>Add To Bag</a>          <?php else: ?>
          <a href="<?php echo e(url('shop/checkout')); ?>" class="btn btn-lg btn-black form-full text-white"><i class="fa fa-shopping-bag left"></i>Check out</a>          <?php endif; ?>

          <!-- Tab -->
          <div class="tabs mt-15">
            <ul>
              <li><a href="#tabs-1">Size</a></li>
              <li><a href="#tabs-2">Color</a></li>
            </ul>

            <div class="ui-tab-content">
              <!-- Description -->
              <div id="tabs-1">
                <p>please choose your size.</p>
                <?php if($product['size']): ?>
                <select id="usersize" class="custom-select">
<?php
    $tempSize = explode(' ', $product['size']);



















































?>
                    <?php $__currentLoopData = $tempSize; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <option value=<?php echo e($size); ?>><?php echo e($size); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> <?php else: ?>
                <select id="usersize" class="custom-select">
          <option value="s">Small</option>
          <option value="m">Medieum</option>
          <option value="l">Large</option>
          <option value="xl">XLarge</option>
                </select> <?php endif; ?>
              </div>
              <div id="tabs-2">
                <?php if($product['color']): ?>
                <p>Please choose your color</p>
                <select id="usercolor" class="custom-select">
    <?php
        $tempColor = explode(' ', $product['color']);



































































?>
                        <?php $__currentLoopData = $tempColor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <option value=<?php echo e($color); ?>><?php echo e($color); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select> <?php else: ?>
                <div id="tabs-2">
                  <p>Please choose your color</p>
                  <select id="usercolor" class="custom-select">
                      <option value="As image">As image</option>
                    </select><?php endif; ?>
                </div>
              </div>

            </div>
          </div>
          <!-- End Tab -->

        </div>
      </div>
      <!-- End Shop info -->
    </div>
  </div>
</section>
<!-- End Shop Item Section -->

<!-- END CONTENT ---------------------------------------------------------------------------->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>