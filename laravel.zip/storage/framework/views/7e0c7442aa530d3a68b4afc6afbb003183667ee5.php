<!-- Favicone Icon -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
<link rel="icon" type="image/png" href="<?php echo e(asset('images/favicon.ico')); ?>">
<link rel="apple-touch-icon" href="<?php echo e(asset('images/favicon.ico')); ?>">

<!-- CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
  crossorigin="anonymous">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- Bootstrap Css -->

<!-- Style Css -->
<link href="<?php echo e(asset('lib/mazel/css/tmp-style.css')); ?>" rel="stylesheet" type="text/css" />
<!-- font Style css -->
<link href="<?php echo e(asset('lib/mazel/css/font-awesome.css')); ?>" rel="stylesheet" type="text/css" />
<!-- icons Style css -->
<link href="<?php echo e(asset('lib/mazel/css/ionicons.css')); ?>" rel="stylesheet" type="text/css" />
<!-- animate css -->
<link href="<?php echo e(asset('lib/mazel/css/plugin/animate.css')); ?>" rel="stylesheet" type="text/css" />
<!-- jquery css -->
<link href="<?php echo e(asset('lib/mazel/css/jquery-ui.css')); ?>" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/"
  crossorigin="anonymous">