 
<?php $__env->startSection('main_content'); ?>
<!-- Shop Item -->

<?php if( $products [0]->ctitle == 'mens'): ?>
<section class="inner-intro bg-image overlay-dark parallax parallax-background1 " data-background-img="<?php echo e(asset('images/mmodel.jpg')); ?>">
  }<?php elseif( $products [0]->ctitle == 'uni-sex'): ?>
  <section class="inner-intro bg-image overlay-dark parallax parallax-background1 " data-background-img="<?php echo e(asset('images/umodel.jpg')); ?>">
    } <?php else: ?>
    <section class="inner-intro bg-image overlay-dark parallax parallax-background1 " data-background-img="<?php echo e(asset('images/model-2.jpg')); ?>">
      } <?php endif; ?>
      <div class="container">
        <div class="row title">
          <h2 class="h2"><?php echo e($products [0]->ctitle); ?> products</h2>

        </div>
      </div>
    </section>
    <!-- End Intro Section -->
    <a class="d-none d-lg-block" href="#" id="scroll" style="display: none;"><span></span></a>

    <div class="container-fluid">
      <!-- Sort List -->
      <div class="row mt-5 mb-5 text-center">
        <div class="col-md-4 shop-filter">
          <p class="mb-2"><strong>Sort by Price:</strong> </p>
          <a href=<?php echo e(url( 'shop/' . $products[0]->curl)); ?>>
                  <button class="btn btn-sm btn-black-line mr-2">Random</button></a>
          <a href=<?php echo e(url( 'shop/' . $products[0]->curl .'\?ob=2')); ?>>
                    <button class="btn btn-md btn-black-line mr-2">High->Low</button></a>
          <a href=<?php echo e(url( 'shop/' . $products[0]->curl . '\?ob=1')); ?>>
                      <button class="btn btn-md btn-black-line">Low->High</button></a>
        </div>
        <div class="col-md-4 shop-filter">
          <p class="mb-2"><strong>Go to:</strong> </p>
          <a href=<?php echo e(url( 'shop/all-products')); ?>>
              <button class="btn btn-md btn-black-line mr-2">All products</button>
            </a>
          <a href=<?php echo e(url( 'shop')); ?>>
              <button class="btn btn-md btn-black-line">Categories page</button>
            </a>
        </div>


        <div class="col-md-4 shop-filter">
          <p class="mb-2"><strong>Shop by Category:</strong> </p>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href=<?php echo e(url( 'shop/' . $category[ 'curl'])); ?>>
              <button class="btn btn-md btn-black-line mr-2"><?php echo e($category['ctitle']); ?></button>
            </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
    <hr>

    <section class="ptb ptb-sm-80">
      <div class="container">
        <div class="row">
          <div class="owl-carousel item4-carousel nf-carousel-theme o-flow-hidden">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="item">
              <div class="nf-col-padding">
                <div class="item-box">
                  <!-- Shop item images -->
                  <div class="shop-item">
                    <div class="item-img">
                      <img src="<?php echo e(asset('images/' . $product->pimage)); ?>" />
                    </div>
                    <div class="item-mask">
                      <div class="item-mask-detail">
                        <div class="item-mask-detail-ele">
                          <a href="<?php echo e(url('shop/' . $product->curl . '/' . $product->purl)); ?>" class="btn btn-line-xs btn-white-line"><i class="fa fa-shopping-cart"></i>More..</a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- End Shop item images -->

                  <!-- Shop item info -->
                  <div class="shop-item-info">
                    <a href="shop-detail.html">
                      <h6 class="shop-item-name"><?php echo e($product->ptitle); ?></h6>
                    </a>
                    <div class="shop-item-price"><span>$<?php echo e($product->price); ?></span></div>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
        </div>
      </div>

    </section>
    <hr>
    <div class="container">
      <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-5 mt-3">
          <div class="item-box">
            <!-- Shop item images -->
            <div class="shop-item">
              <div class="item-img">
                <img src="<?php echo e(asset('images/' . $product->pimage)); ?>" alt="<?php echo e($product->ptitle); ?> product image">
              </div>
              <div class="item-mask">
                <div class="item-mask-detail">
                  <div class="item-mask-detail-ele">
                    <a class="btn btn-line-xs btn-white-line text-white" href="<?php echo e(url('shop/' . $product->curl . '/' . $product->purl)); ?>">More details</a>                    <?php if(! Cart::get($product->id) ): ?>
                    <a class="btn btn-line-xs btn-white-line text-white add-to-cart-btn" data-id="<?php echo e($product->id); ?>"><i class="fa fa-shopping-cart"></i>Add To Cart</a>                    <?php else: ?>
                    <a href="<?php echo e(url('shop/checkout')); ?>" class="btn btn-line-xs btn-white-line btn-white-line"><i class="fa fa-shopping-cart"></i>Check out</a>                    <?php endif; ?>

                  </div>
                </div>
              </div>
            </div>
            <!-- End Shop item images -->

            <!-- Shop item info -->
            <div class="shop-item-info">
              <h4 class="shop-item-name"><?php echo e($product->ptitle); ?></h4>
              <h6 class="shop-item-name"><?php echo $product->particle; ?></h6>
              <div class="shop-item-price"><span>$ <?php echo e($product->price); ?></span></div>
            </div>
          </div>
          <!-- Shop item info -->


        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      </div>
    </div>

    <?php echo e($products->appends(request()->query())->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>