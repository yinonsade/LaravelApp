 
<?php $__env->startSection('main_content'); ?>



<!-- Intro Section -->
<section class="inner-intro bg-image overlay-light parallax parallax-background1" data-background-img="<?php echo e(asset('images/about.jpg')); ?>">
    <div class="container">
        <div class="row title">
            <h2 class="h2">About Us</h2>

        </div>
    </div>
</section>

<section class="ptb ptb-sm-80">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-12">
                <h3><?php echo e($content->title); ?></h3>
                <p class="lead"><?php echo $content->article; ?></p>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</section>





<!-- Statement Section -->
<section class="dark-bg  ptb-60" id="statement">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h4 class="mb-15">E22</h4>
                <a href="<?php echo e(url('shop')); ?>" class="btn btn-md btn-white">GO TO SHOP</a>
            </div>
        </div>
    </div>
</section>
<!-- End Statement Section -->

<!-- About Section -->

<!-- End CONTENT ------------------------------------------------------------------------------>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>