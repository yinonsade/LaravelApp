<div class="container">
  <div class="row">
    <div class="col-12">
      <h1>{{$name}}, Thank you for Register to E2.1.8</h1>
      <img style="width:200px, hight:300px;" src="{{asset('images/e22_logo_w.jpg')}}">
      <a href="www.e218.com">
        <h3>go to site</h3>
      </a>
    </div>
  </div>
</div>