<h3>you have a new contact via the contact form</h3>

<div>
  {{ $bodyMessage }}
</div>
<p>
  from: {{$name}}
</p>
<p>
  send via {{$email}}
</p>